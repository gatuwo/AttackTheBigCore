# Rapid-fire fix (玉詰まり解消) — 2026-02-14

## 何が起きていたか（症状）
- 弾を連打すると「前に出ない / すぐ消える」ように見える（玉詰まり）。

## 原因
1. **弾(Bullet)の当たり判定がプレイヤー自身にも反応**していた
   - `bullet.gd` は `body_entered` で衝突したら `queue_free()` していたが、
	 Bullet の Collision 設定がデフォルト(=Playerとも当たる)のため、
	 生成直後に Player に触れてしまうケースがあり、弾が即消滅していた。

2. **発射処理で add_child 前に global_position を設定**していた
   - Godot では「ツリーに入っていないノード」の `global_position` は、
	 親の Transform などの影響で意図しない再計算が入ることがある。
	 連打時にこれが目立ち、弾の出現位置が安定しないことがある。

3. 単発発射（just_pressed）だったため、連射実装も合わせて追加した

## 修正内容
### player.gd
- 移動処理を `_process` → `_physics_process` に変更（CharacterBody2Dの推奨）
- 連射用のクールダウンを追加： `fire_rate`（秒間発射数）と `_fire_cd`
- 発射入力を `is_action_just_pressed` → `is_action_pressed` に変更（押しっぱなし連射）
- **弾生成の順番を修正**： `add_child()` してから `global_position` を設定
- 砲口位置を固定するため `Marker2D (Muzzle)` を追加し、そこから出すように対応
- Player を `player` グループに追加（弾が自機を無視できるようにする）

### player.tscn
- `Marker2D` ノード `Muzzle` を追加（position=(30,0)）

### bullet.gd
- `body_entered` で **Player を無視**する処理を追加（玉詰まり対策）
- 移動を `position.x += ...` から `global_position.x += ...` に変更（親の影響を受けにくく）

## 使い方（調整）
- 連射速度は Player ノードの Inspector で `fire_rate` を変更
  - 例：12 = 1秒に12発
- 発射位置は `Player/Muzzle` の位置を動かして調整
